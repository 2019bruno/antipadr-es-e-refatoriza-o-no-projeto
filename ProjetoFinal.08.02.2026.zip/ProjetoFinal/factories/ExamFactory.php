<?php
declare(strict_types=1);

final class ExamFactory {
    /**
     * Factory Method (simplificado): cria a estrutura de analytics conforme o tipo de pedido.
     */
    public static function create(string $requestType): array {
        $now = (new DateTimeImmutable())->format(DATE_ATOM);

        // No futuro: branching por requestType (switch/registry).
        return [
            'requestType' => $requestType,
            'generatedAt' => $now,
            'summary' => [
                'items' => 0,
                'notes' => 'Dados de exemplo (stub)'
            ],
        ];
    }
}
