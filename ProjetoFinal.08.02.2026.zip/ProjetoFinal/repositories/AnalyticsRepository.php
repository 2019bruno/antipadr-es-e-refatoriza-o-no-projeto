<?php
declare(strict_types=1);

/**
 * Repositório (camada de persistência).
 * Nesta versão é um stub (não há BD), mas a interface mantém o contrato.
 */
final class AnalyticsRepository {
    public function save(array $analytics): bool {
        // Exemplo: poderia gravar em BD/ficheiro.
        return true;
    }
}
