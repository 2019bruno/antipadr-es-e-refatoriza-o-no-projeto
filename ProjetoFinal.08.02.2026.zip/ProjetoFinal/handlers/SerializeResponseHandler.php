<?php
declare(strict_types=1);

final class SerializeResponseHandler extends Handler {
    protected function process(Context $context): Context {
        $payload = [
            'status' => 'ok',
            'analytics' => $context->analytics,
            'metadata' => array_diff_key($context->metadata, ['repo' => true]), // não serializar objetos
        ];

        $json = json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            throw new RuntimeException('Falha ao serializar resposta JSON.');
        }

        return $context->withResponse($json);
    }
}
