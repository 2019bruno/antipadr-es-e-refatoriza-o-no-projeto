<?php
declare(strict_types=1);

final class ResolveRepositoryHandler extends Handler {
    public function __construct(private readonly AnalyticsRepository $repo = new AnalyticsRepository()) {}

    protected function process(Context $context): Context {
        // Armazenar repo no metadata do contexto (evita carregar num array solto)
        $meta = $context->metadata;
        $meta['repo'] = $this->repo;
        return new Context($context->requestType, $meta, $context->analytics, $context->responseJson);
    }
}
