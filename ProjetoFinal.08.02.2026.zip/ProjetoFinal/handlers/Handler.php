<?php
declare(strict_types=1);

abstract class Handler {
    private ?Handler $next = null;

    public function setNext(Handler $handler): Handler {
        $this->next = $handler;
        return $handler;
    }

    final public function handle(Context $context): Context {
        $context = $this->process($context);
        return $this->next ? $this->next->handle($context) : $context;
    }

    /** Cada handler implementa apenas a sua responsabilidade. */
    abstract protected function process(Context $context): Context;
}
