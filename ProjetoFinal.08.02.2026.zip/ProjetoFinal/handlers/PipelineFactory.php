<?php
declare(strict_types=1);

final class PipelineFactory {
    public static function build(): Handler {
        $validate = new ValidateRequestHandler();
        $resolve  = new ResolveRepositoryHandler();
        $build    = new BuildAnalyticsHandler();
        $serial   = new SerializeResponseHandler();

        $validate->setNext($resolve)->setNext($build)->setNext($serial);
        return $validate;
    }
}
