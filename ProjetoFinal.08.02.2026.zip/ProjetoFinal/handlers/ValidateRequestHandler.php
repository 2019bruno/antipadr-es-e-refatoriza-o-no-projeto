<?php
declare(strict_types=1);

final class ValidateRequestHandler extends Handler {
    protected function process(Context $context): Context {
        // Validações mínimas
        if (trim($context->requestType) === '') {
            throw new InvalidArgumentException('Tipo de request em falta.');
        }
        return $context;
    }
}
