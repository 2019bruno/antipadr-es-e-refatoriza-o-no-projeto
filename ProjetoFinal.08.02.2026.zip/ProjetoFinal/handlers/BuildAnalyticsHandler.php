<?php
declare(strict_types=1);

final class BuildAnalyticsHandler extends Handler {
    protected function process(Context $context): Context {
        $analytics = ExamFactory::create($context->requestType);

        // Persistência (opcional) via repositório, se existir no metadata
        $repo = $context->metadata['repo'] ?? null;
        if ($repo instanceof AnalyticsRepository) {
            $repo->save($analytics);
        }

        return $context->withAnalytics($analytics);
    }
}
