<?php
declare(strict_types=1);

/**
 * Bootstrap do ProjetoFinal
 * - Autoload simples para classes do projeto (sem Composer).
 * - Configurações gerais.
 */

spl_autoload_register(function (string $class): void {
    $baseDir = __DIR__ . DIRECTORY_SEPARATOR;

    $map = [
        'adapters' => $baseDir . 'adapters' . DIRECTORY_SEPARATOR,
        'handlers' => $baseDir . 'handlers' . DIRECTORY_SEPARATOR,
        'repositories' => $baseDir . 'repositories' . DIRECTORY_SEPARATOR,
        'factories' => $baseDir . 'factories' . DIRECTORY_SEPARATOR,
        'models' => $baseDir . 'models' . DIRECTORY_SEPARATOR,
    ];

    foreach ($map as $dir) {
        $file = $dir . $class . '.php';
        if (is_file($file)) {
            require_once $file;
            return;
        }
    }
});
