<?php
declare(strict_types=1);

/**
 * Contexto imutável por convenção (passado como array associativo é mais simples,
 * mas esta classe ajuda a validar e documentar o que circula no pipeline).
 */
final class Context {
    public function __construct(
        public readonly string $requestType,
        public readonly array $metadata = [],
        public readonly array $analytics = [],
        public readonly ?string $responseJson = null
    ) {}

    public function withAnalytics(array $analytics): self {
        return new self($this->requestType, $this->metadata, $analytics, $this->responseJson);
    }

    public function withResponse(string $json): self {
        return new self($this->requestType, $this->metadata, $this->analytics, $json);
    }
}
