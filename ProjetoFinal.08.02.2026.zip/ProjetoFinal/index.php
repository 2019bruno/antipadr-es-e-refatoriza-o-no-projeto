<?php
declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

try {
    $adapter = new InveniraAdapter();

    $context = new Context(
        requestType: $adapter->getRequestType(),
        metadata: $adapter->getClientMetadata()
    );

    $pipeline = PipelineFactory::build();
    $result = $pipeline->handle($context);

    header('Content-Type: application/json; charset=utf-8');
    echo $result->responseJson ?? json_encode(['status' => 'ok']);

} catch (Throwable $e) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
}
