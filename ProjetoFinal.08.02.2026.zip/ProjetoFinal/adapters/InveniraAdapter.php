<?php
declare(strict_types=1);

/**
 * Adapter: traduz o pedido do cliente externo para o formato interno.
 * Nesta versão, é simulado (stub). Em ambiente real, leria body JSON/POST.
 */
final class InveniraAdapter {
    public function getRequestType(): string {
        // Exemplo de leitura robusta: tenta JSON, depois POST, depois default
        $raw = file_get_contents('php://input') ?: '';
        if ($raw !== '') {
            $decoded = json_decode($raw, true);
            if (is_array($decoded) && isset($decoded['requestType']) && is_string($decoded['requestType'])) {
                return $decoded['requestType'];
            }
        }

        if (isset($_POST['requestType']) && is_string($_POST['requestType'])) {
            return $_POST['requestType'];
        }

        return 'ExamAnalytics';
    }

    public function getClientMetadata(): array {
        return [
            'client' => 'Inven!RA',
            'timestamp' => (new DateTimeImmutable())->format(DATE_ATOM),
        ];
    }
}
