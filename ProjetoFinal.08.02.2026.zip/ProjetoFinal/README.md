# ProjetoFinal – Activity Provider (Activity Provider)

## Objetivo
Implementação demonstrativa de um *Activity Provider* usando padrões de desenho:
- **Adapter** (`InveniraAdapter`)
- **Factory Method** (`ExamFactory`)
- **Chain of Responsibility** (pipeline de handlers)

## Estrutura
- `index.php`: ponto de entrada
- `bootstrap.php`: autoload e configurações
- `adapters/`: adapters de entrada
- `handlers/`: cadeia de processamento
- `factories/`: criação de objetos/estruturas
- `repositories/`: persistência (stub)
- `models/`: modelos (ex.: `Context`)

## Execução (CLI)
```bash
php -S localhost:8000
# abrir: http://localhost:8000/index.php
```

## Exemplo de request
```bash
curl -X POST http://localhost:8000/index.php -H "Content-Type: application/json" -d '{"requestType":"ExamAnalytics"}'
```

Data: 2026-02-08
